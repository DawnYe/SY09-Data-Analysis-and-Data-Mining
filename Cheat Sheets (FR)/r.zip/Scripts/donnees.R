# Gestion des structures de donn�es (data.frame)
           

####################################################################
# Cr�ation de donn�es

# Donn�es simul�es
x1=runif(30,0,1)     
x2=runif(30,5,10) 
x3=x1+rnorm(30,0,0.05)
x4=rbinom(30,3,0.2)
x=data.frame(v1=x1,v2=x2,v3=x3,v4=x4)
x$v4=factor(x$v4,labels=c("A","B","C"))
save(x,file="exemple1.Rdata")
 


# A partir d'un fichier ascii suivant :
#     sexe taille poids yeux age cheveux
#     Pierre       M 1.80 85 bleu     23 chatain
#     Gabrielle    F 1.65 55 marron   18 brun
#     Paul         M 1.60 60 marron   34 chatain
#     Clara        F 1.50 45 bleu     17 blond
#     Gaspard      M 1.92 78 marron   28 brun
#     Jean         M 1.63 54 marron   40 brun
#     Michel       M 1.69 80 bleu     37 blond
#     Alain        M 1.73 74 bleu     42 brun
#     Louise       F 1.59 48 marron   33 chatain
#     Karine       F 1.63 47 marron   25 chatain
x=read.table('exemple2.txt') 
save(x,file="exemple2.Rdata")    



#  A partir d'un fichier Excel :
#  Le fichier Excel exemple3.xls suivant
#         A    B         C       D      E
# 1     	  var 1	   var 2   var 3   var 4
# 2     ind1	8	6	5	12,78
# 3     ind2	7	7	3	45,34
# 4     ind3	6	5	4	45,94
# 5     ind4	7	5	4	12,52
# 6     ind5	4	8	6	80,45
# 7     ind6	2      12	9	55,23
#
#  est au pr�alable recopier au format csv dans le fichier 
#  exemple3.csv.
data<-read.csv2("exemple3.csv",row.names=1)
save(notes,file="exemple3.Rdata")



# Iris de Fisher
iris<-read.table("iris.txt")
iris$Esp�ce=factor(iris$Esp�ce,labels=c("Setosa","Versicolor","Virginia"))
save(iris,file="iris.Rdata")



# Notes
notes<-read.table("notes.txt")
save(notes,file=".notes.Rdata")
        
####################################################################
# Information, S�lection et Edition d'un data.frame
load("exemple2.Rdata")    
attributes(x)
class(x$poids)
class(x$taille)
class(x$cheveux)
names(x)
rownames(x)
length(x)
n=dim(x)[1]                     # Taille de l'�chantillon    
d=dim(x)[2]                     # Nombre de variables    

load("exemple1.Rdata")    
x$v2
x[[2]]
x[,2]
x[,'v2']
x.qan=x[sapply(x,is.numeric)]       # S�lection des var. quant.
x.qal=x[sapply(x,is.factor)]        # S�lection des var. qual. 

y<-edit(x)


