x=matrix(c(0,13,5,1,20,13,0,2,10,1.5,5,2,0,4,6,1,10,4,0,17,20,1.5,6,17,0),nrow=5)
d=as.dist(x)
h= hclust(d, method = "complete")
plot(h)