# Exemple1
x=read.table('exemple2.txt')     
x.qan=x[sapply(x,is.numeric)]                    # S�lection des var. quant.
x.qal=x[sapply(x,is.factor)]                     # S�lection des var. qual. 
n=dim(x)[1]                                      # Taille de l'�chantillon    
attach(x)

x                                                # Les donn�es
summary(x)                                       # R�sum� num�rique 
boxplot(x.qan)                                   # Diagramme en bo�te
print(mean(x.qan),digits=3)                      # Moyennes 
print(sd(x.qan),digits=3)                        # Ecarts-types
print(cor(x.qan),digits=2)                       # Matrice de corr�lation
stem(poids)                                      # Diagramme en tige et feuille 
stem.leaf(poids)                                 # Idem (package aplpack)
hist(taille,col="blue",main="Taille")            # Histogramme
plot(taille,poids,type='n')                      # Affichage du plan (taille,poids)
text(taille,poids,rownames(x))
plot(sort(taille),(1:n)/n,type='s',ylim=c(0,1))  # Trac� de la f.d.r
pairs(x.qan)                                     # Graphique matriciel
faces(x.qan)                                     # Visages de Chernoff (package aplpack)
stars(x.qan)                                     # Polygones
layout(matrix(c(1,3,5,2,4,6),2,3, byrow=T))      # Description de var. qual.
for (j in 1:3){      
  pie(table(x.qal[,j]))                          # Diagrammes en b�ton
  barplot(table(x.qal[,j]))                      # Diagrammes en camenbert
}
table(yeux,cheveux)                              # Table de contingence
mosaicplot(table(yeux,cheveux))
boxplot(poids~cheveux)                           # Var. quan.  vs. var. qual.
aggregate(x[,c(2,3,5)],list(cheveux=x$cheveux),mean)

detach(d)


####################################################################
# Exemple simul�
load("exemple1.Rdata")
attributes(d)
names(d)
rownames(d)
d$v2
d[[2]]
d[,2]
d[,'v2']
length(d)



####################################################################
# Nombre d'enfants dans une famille
enfants <- read.table("enfants.txt")
attach(enfants)

# Calcul du tableau des fr�quences
nk<-as.vector(table(nb))
fk=nk/sum(nk)
Fk=cumsum(fk)
f=data.frame(nk,fk,Fk,row.names=sapply(min(nb):max(nb),"toString"))

# Affichage du tableau des fr�quences
format(f,digits=2)

# Affichage du diagramme en b�ton
barplot(nk,col="blue")

#####################################################################
####################################################################
# Densit� du globe
data <- read.table("cavendish.txt",header=TRUE)
attach(data)

# D�finition des intervalles
bornes=4.75+0.25*(0:5)

# Calcul du tableau des fr�quences
tmp<-table(cut(densit�,breaks=bornes))
nk=as.vector(tmp)
fk=nk/sum(nk)
Fk=cumsum(fk)
f=data.frame(nk,fk,Fk,row.names=rownames(tmp))

# Affichage du tableau des fr�quences
format(f,digits=2)

# Affichage de l'histogramme
h<-hist(densit�,breaks=bornes,freq=FALSE,col="lightblue",main="Densit� du globe terrestre",ylab="densit�")
curve(dnorm(x,mean=mean(densit�),sd=sd(densit�)), col = 2, lty = 1, lwd = 2, add = TRUE)

####################################################################
####################################################################
# Vitesse de la lumi�re
newcomb <- read.table("newcomb.txt",header=TRUE)
attach(newcomb)

# Affichage des principales statistiques �l�mentaires
summary(v)

# Trac� de l'histogramme
hist(v,nclas=10,freq=FALSE,col="lightblue",main="Vitesse de la lumi�re",ylab="densit�")
curve(dnorm(x,mean=mean(v),sd=sd(v)), col = 2, lty = 2, lwd = 2, add = TRUE)

# Affichage temporel
plot(v,type="l",main="Graphique temporel : vitesse de la lumi�re")

# Trac� de l'histogramme apr�s suppression des 2 outliers
v1=v[v>0]
hist(v1,nclas=10,freq=FALSE,col="lightblue",main="Vitesse de la lumi�re (sans outliers)",ylab="densit�")
curve(dnorm(x,mean=mean(v1),sd=sd(v1)), col = 2, lty = 2, lwd = 2, add = TRUE)


# Affichage du boxplot
boxplot(v,main="Vitesse de la mumi�re")

#####################################################################
####################################################################
# Poisson de la Tennessee
tennessee <- read.table("tennessee.txt",header=TRUE)
attach(tennessee)
hist(ddt,nclas=8,freq=FALSE,col="lightblue",main="Poissons de la Tennessee",ylab="densit�")
curve(dnorm(x,mean=mean(ddt),sd=sd(ddt)), col = 2, lty = 2, lwd = 2, add = TRUE)

# Affichage apr�s transformation logarithmique
log_ddt=log(ddt)
hist(log_ddt,nclas=8,freq=FALSE,col="lightblue",main="Poissons de la Tennessee",,ylab="densit�")
curve(dnorm(x,mean=mean(log_ddt),sd=sd(log_ddt)), col = 2, lty = 2, lwd = 2, add = TRUE)


#####################################################################
####################################################################
# Baseball
base_ball <- read.table("base_ball1.txt",,header=TRUE)
attach(base_ball)
stem(Ruth)

base_ball <- read.table("../Data/base_ball2.txt",,header=TRUE)
attach(base_ball)
stem(Moris)

#####################################################################
####################################################################
# Iris de Fisher
load("iris.Rdata")
attach(iris)

# Les donn�es
iris

# Description �l�mentaires
summary(iris)
pie(summary(Esp�ce))
barplot(summary(Esp�ce))

stem(iris)

# Description de la variable esp�ce pour une partie des iris
pie(summary(iris[LoSe>5,1]),main='(a)')
barplot(summary(iris[LoSe>5,1]),main='(b)')

# Histogramme de la variable LoPe
inter=seq(min(LoPe),max(LoPe),by=(max(LoPe)-min(LoPe))/10)
hist(LoPe,breaks=inter,col="blue",main="Longueur du p�tale")c

# Histogramme d�coup� suivant la variable Esp�ce
inter=seq(min(LoPe),max(LoPe),by=(max(LoPe)-min(LoPe))/10)
h1=hist(plot=F,LoPe[Esp�ce=='Setosa'],breaks=inter)
h2=hist(plot=F,LoPe[Esp�ce=='Versicolor'],breaks=inter)
h3=hist(plot=F,LoPe[Esp�ce=='Virginia'],breaks=inter)
# en couleur
barplot(rbind(h1$counts,h2$counts,h3$counts),space=0,col=c('blue','red','yellow'),legend=levels(Esp�ce),main="Longueur du p�tale")
# en gris
barplot(rbind(h1$counts,h2$counts,h3$counts),space=0,legend=levels(Esp�ce),main="Longueur du p�tale")


# Boxplot des 4 variables de longueur
boxplot(iris[2:5])

# Matrice de covariance et de corr�lation
print(cor(iris[,2:5]),digits=3)
print(cov(iris[,2:5]),digits=3)

# Graphe matriciel
pairs(iris[,2:5],main="Les Iris")

# Graphe matriciel avec les esp�ces
pairs(iris[2:5], main="Les 3 esp�ces d'Iris", pch=21,bg=c("red", "green3", "blue")[Esp�ce])

# Affichage des iris avec couleurs diff�rentes suivant l'esp�ce
plot(iris[,c(2,3)],main="Donn�e Iris",pch=21,bg=c("red","yellow","blue")[iris$Esp�ce])

# Affichage des iris avec des symboles formes diff�rentes suivant l'esp�ce
plot(iris[,c(2,3)],main="Donn�e Iris",pch=c(19,22,24)[iris$Esp�ce])

# Affichage de 100 iris avec symboles diff�rents suivant l'esp�ce
plot(iris[c(1: 50,101:150),c(2,3)],main="Donn�es Iris",pch=c(19,22)[iris$Esp�ce])
#####################################################################
####################################################################
# Notes
load("notes.Rdata")
attach(notes)

# Affichage du plan (maths,science)
plot(math,scie,type='n',main='Exemple des notes')
text(math,scie,labels=rownames(notes))

# Visages de Chernoff
faces(notes)

# Polygones
stars(notes)

#####################################################################
####################################################################
# Notes1
load("notes1.Rdata")
attach(notes)
n<-notes[,1:4] # n contient uniquement les 4 notes 

notes                                       # Les donn�es
summary(notes)                              # R�sum� num�rique 
boxplot(n)                                  # Diagramme en bo�te
print(mean(n),digits=3)                     # Moyennes 
print(sd(n),digits=3)                       # Ecarts-types
print(cor(n),digits=2)                      # Matrice de corr�lation
stem(fran�ais)                              # Diagramme en tige et feuille 
stem.leaf(fran�ais)                         # Idem (package aplpack)
hist(math,col="blue",main="Math�matiques")  # Histogramme
barplot(table(sexe))                        # Diagramme en b�ton
pie(table(sexe))                            # Diagramme en camenbert
table(sexe,ecole)                           # Table de contingence
pairs(n)                                    # Graphique matriciel
faces(n)                                    # Visages de Chernoff (package aplpack)
stars(n)                                    # Polygones
plot(math,scie,type='n',main='Notes')       # Affichage du plan (maths,science)
text(math,scie,labels=rownames(notes))
