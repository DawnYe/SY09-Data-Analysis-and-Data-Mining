# Cr�ation de fichiers de figures                                        

# Un graphique en ligne
postscript(file='DESCRI_boxplot_iris.eps',horizontal=F,width=8/2.5,height=8/2.5)
par(cex=0.5,mex=0.5)
boxplot(iris[2:5])
dev.off()

# Deux graphiques en ligne
postscript(file='DESCRI_pie_barre_iris.eps',horizontal=F,width=15/2.5,height=8/2.5)
par(mfrow=c(1,2),cex=0.5,mex=0.5)
pie(summary(type))
barplot(summary(type))
dev.off()

# Deux graphiques en ligne
layout(matrix(c(1,3,5,2,4,6),2,3, byrow=T))      # Description de var. qual.


#####################################################################
####################################################################
