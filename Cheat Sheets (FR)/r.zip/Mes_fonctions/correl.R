correl<-function(data)
### Affiche le tableau de corr�lation avec les ast�riques des significativit� et
### retourne une liste compos�e du tableau de corr�lations et du tableau des p_values.
  
{d<-dim(data)[2]
 
 ## Affichage 1�re ligne
 cat("       ")                         
 for (j2 in 1:d) cat(sprintf("%-10s",names(data)[j2]))
 cat("\n")
 

 ## Calcul des matrices et affichage
 c<-matrix(0,d,d)
 p<-matrix(0,d,d)

 for (j1 in 1:d)  
   { cat(sprintf("%-5s",names(data)[j1]))
     for (j2 in 1:d)   
       { if (j1==j2) 
           {cat(sprintf("%6.3f",1),"   ") 
            c[j1,j2]<-1
            p[j1,j2]<-0}
       else
         { res<-cor.test(data[,j1],data[,j2])
           c[j1,j2]<-res$estimate
           p[j1,j2]<-res$p.value
           c[j2,j1]<-res$estimate
           p[j2,j1]<-res$p.value
           if (res$p.value <=0.001)
             ast<-"***"
           else if (res$p.value <=0.01)
             ast<-"** "
           else if (res$p.value <=0.05)
             ast<-"*  "
           else
             ast<-"   "
           cat(sprintf("%6.3f",res$estimate),ast)
         }
         }
     cat("\n")
   }
 return (list(cor=c,p_value=p))
}
